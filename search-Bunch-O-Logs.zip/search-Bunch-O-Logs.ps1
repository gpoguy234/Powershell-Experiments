﻿# ########################################################################################################################################
# Filename: search-bunch-O-Logs.ps1
#
# Description: This script will search the current director for evtx files and parse the last 10000 messages for the keyword you specify 
#
# version 1
# Created By: Matt Elliott
# Created On: May 22, 2021
# Edited On: May 24, 2021 - added eventID search option
#
#########################################################################################################################################

function get-all-eventsMessage($param){
     if ($param -match "y"){
        $key = read-host "enter a search term" ;  $list = ls *.evtx ; foreach ($file in $list.Name) { write-output "searching $file" ; Get-WinEvent -FilterHashtable @{ 
                Path=$file
            } | where { $_.Message -like "*$key*" } | Export-Csv -Path $key-search.csv  -NoTypeInformation -Append ;
            write-output "done...."
        } 
    }
    else{ #work in progress - not limited to certain rows anymore
        $key = read-host "enter a search term"; $list = ls *.evtx ; foreach ($file in $list.Name) { write-output "searching $file" ; Get-WinEvent -FilterHashtable @{ 
            Path=$file
            } | where { $_.Message -like "*$key*" } | Export-Csv -Path $key-search.csv  -NoTypeInformation -Append ;
            write-output "done.... "
        }
    }
    write-output "done.... view results file: $key-search.csv"
}


function get-all-eventsID($param){
    if ($param -match "y"){
        $key = read-host "enter Event ID" ;  $list = ls *.evtx ; foreach ($file in $list.Name) { write-output "searching $file" ; Get-WinEvent -FilterHashtable @{ 
                Path=$file
                ID=$key
            } | Export-Csv -Path $key-search.csv  -NoTypeInformation -Append ;
            write-output "done...."
        } 
    }
    else{ #work in progress - currently same results as above
        $key = read-host "enter Event ID"; $list = ls *.evtx ; foreach ($file in $list.Name) { write-output "searching $file" ; Get-WinEvent -FilterHashtable @{ 
            Path=$file
            ID=$key
            } | Export-Csv -Path $key-search.csv  -NoTypeInformation -Append ;
            write-output "done...."
        }
    }
    write-output "done.... view results file: $key-search.csv"
}

$param = Read-host "search entire event logs? Y or N (N will search last 10000 events)"
$mode = Read-host "Search by Message field (s) or Event ID (n)?"
#$param = "y"
if($mode -match "s"){
    get-all-eventsMessage($param)
}
else{
    get-all-eventsID($param)
}