﻿# ########################################################################################################################################
# Filename: search-bunch-O-Logs.ps1
#
# Description: This script will search the current director for evtx files and parse the last 10000 messages for the keyword you specify 
#
# version 1
# Created By: Matt Elliott
# Created On: May 22, 2021
# Edited On: 
#
#########################################################################################################################################

function get-all-events($param){
if ($param -match "y"){
    $key = read-host "enter a search term" ; $list = ls *.evtx ; foreach ($file in $list.Name) { write-output "searching $file" ; Get-WinEvent -Path .\$file | where { $_.Message -Match "$key" } | Export-Csv -Path $key-search.csv  -NoTypeInformation -Append} 
    write-output "done.... view results file: $key-search.csv"
    }
else{
    $key = read-host "enter a search term" ; $list = ls *.evtx ; foreach ($file in $list.Name) { write-output "searching $file" ; Get-WinEvent -Path .\$file  -MaxEvents 10000 | where { $_.Message -Match "$key" } | Export-Csv -Path $key-search.csv  -NoTypeInformation -Append} 
    write-output "done.... view results file: $key-search.csv"
    }
}
$param = Read-host "search entire event logs? Y or N (N will search last 10000 events)"
get-all-events($param)