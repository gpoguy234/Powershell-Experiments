﻿<#
.SYNOPSIS
  Name: zip-Script.ps1
  The purpose of this script is to generate a password protected zip file and sends a simple email with the password to the user specified (me by default)
  
.DESCRIPTION
  This script will zip files placed in the Input directory to a file called zipped.zip  and email to matt.elliott@gibsonenergy.com.   
  The sender can be changed as needed in the script - future functionality will include command line based sending.

.NOTES
    Updated: 
    Release Date: 2018-04-23
   
  Author: Matt Elliott

.EXAMPLE
  Run the Get-Example script to create the c:\example folder:
  Get-Example -Directory c:\example

See Help about_Comment_Based_Help for more .Keywords

# Comment-based Help tags were introduced in PS 2.0
#requires -version 2
#>

[CmdletBinding()]
#Path to 7-zip executable
$pathTo64Bit7Zip = ".\7zip\7za.exe"
#Path to output folder
$ZipOutputFilePath = ".\Output\zipped"
$FilesToZip = ".\Input\*"
# email will be sent to the following user(s) - send to multiple emails as specified in sendto.txt - all one line - emails seperated with semi-colon - no spaces
$To = Get-Content .\sendto.txt


#Generate Random password and store in passwords.txt file
[Reflection.Assembly]::LoadWithPartialName("System.Web")
$randomPassword = [System.Web.Security.Membership]::GeneratePassword(15,2)
write-output " your random password is: $randomPassword" | out-file .\passwords.txt -append

#Zip the files to Output\Zipped.zip
$arguments = "a -tzip ""$ZipOutputFilePath"" ""$FilesToZip"" -mx9 -p$randomPassword"
$windowStyle = "Normal"
$p = Start-Process $pathTo64Bit7Zip -ArgumentList $arguments -Wait -PassThru -WindowStyle $windowStyle

#Show file details
Write-Output "Files that were zipped"
ls .\Input\
Write-Output "zipped file location"
ls .\Output\
# Open password file
notepad .\passwords.txt

# Email send 
<#
# Email zip file - work in progress
$Subject = "FILE for $(get-date -f yyyy-MM-dd)"
$Body =  "see attached..."
$Outlook = New-Object -ComObject Outlook.Application
$Msg = $Outlook.CreateItem(0)
$Msg.To = $To
$Msg.Subject = $Subject
$Msg.Body = $Body
$Msg.Attachments = $ZipOutputFilePath
$Msg.Send()
#>

#email password
$Subject = "CSV for $(get-date -f yyyy-MM-dd)"
$Body =  $randomPassword
$Outlook = New-Object -ComObject Outlook.Application
$Msg = $Outlook.CreateItem(0)
$Msg.To = $To
$Msg.Subject = $Subject
$Msg.Body =$Body
$Msg.Send()

#end