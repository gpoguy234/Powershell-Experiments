﻿<#
.SYNOPSIS
    Summarize Qualys Map scan csv exports

.DESCRIPTION
    USe this script to parse info out of qualys Map scan results - note that the file name 

.EXAMPLE
    just extract and run.  if powershell execution policy error occurs, run with bypass

      
.AUTHOR
    Matt Elliott

.REVISION
    v1.0
    Original release
.Date
    Nov 25 2019
#>

# parameters 
#Define path used save data report
$lcldir = ((Get-ChildItem).DirectoryName)[0]
$reportpath = "$lcldir\report\"
#Define path for raw Qualys csv files
$datapath = "$lcldir\data\"
# get list of data files - if multiple exist
$files = dir $datapath -Name *.csv

#Get minimum severity $minPriority = read-host "Enter the minimum Priority alert to include in the report (0-5)"
$pick = read-host "Enter the minimum Priority alert to include in the report (0-5)" 
if((0,1,2,3,4,5) -match $pick){$minsev = $pick} 
else {write-host "incorrect value entered, setting to default (0)";$minsev = 0}

#Define HTML style
$css = @"
<style>
h1, h5, th { text-align: center; font-family: Segoe UI; }
table { margin: auto; font-family: Segoe UI; box-shadow: 10px 10px 5px #888; border: thin ridge grey; }
th { background: #2A5124; color: #fff; max-width: 400px; padding: 5px 10px; }
td { font-size: 11px; padding: 5px 20px; color: #000; }
tr { background: #b8d1f3; }
tr:nth-child(even) { background: #dae5f4; }
tr:nth-child(odd) { background: #b8d1f3; }
</style>
"@

#if($files.count -le 1)
foreach($obj in $files){

    #get the name of the scan from the csv data
    $def = Get-Content -Path $obj.PSPath | Select-Object -Skip 4 | ConvertFrom-Csv
    $scantype = $def[0].' Option profile' #  Mapping and Host Discovery

    #get the scan data
    $abc = get-content -Path $obj.PSPath| Select-Object -Skip 7 | Out-String | ConvertFrom-Csv
    
    If($scantype -Match "Mapping"){
        $fn = ($def[0].' Title').Replace("Map Scan - ","")
        write-host "Map processing $fn"
        #If previous file exists - rename
        If (Test-Path -path "$reportpath\$fn Qualys-Map-Report.html"){
            $DateStamp = get-date -uformat "%Y-%m-%d@%H-%M-%S"
            Rename-Item "$reportpath\$fn Qualys-Map-Report.html" -NewName "$reportpath\$fn Qualys-Map-Report$DateStamp.html"
        }
        #filter the map data based on the minimum severity
        $abc | Select-Object -Property IPHost,DiscoveryMethod,Live,Scannable | ConvertTo-Html -Head $css -Body "<h1> $fn Qualys Map Scan Results</h1>`n<h5>Generated on $(Get-Date)</h5>" | Out-File "$reportpath\$fn Qualys-Map-Report.html"
    }
    else{
        $fn = $def[0].'Scan Title'
        write-host "Vuln scan processing $fn"
        #If previous file exists - rename
        If (Test-Path -path "$reportpath\$fn MinSev-$minsev Qualys-Report.html"){
            $DateStamp = get-date -uformat "%Y-%m-%d@%H-%M-%S"
            Rename-Item "$reportpath\$fn MinSev-$minsev Qualys-Report.html" -NewName "$reportpath\$fn MinSev-$minsev Qualys-Report$DateStamp.html"
            }
        #filter the Vuln data based on the minimum severity
        $abc | where-object -Property Severity -GE $minsev | sort -property Severity -Descending | Select-Object -Property Severity, IP, Category, QID, Title, Threat, Solution | ConvertTo-Html -Head $css -Body "<h1> $fn Qualys Vulnerability Scan Results</h1>`n<h5>Generated on $(Get-Date)</h5>" | Out-File "$reportpath\$fn MinSev-$minsev Qualys-Report.html"

        }
    
}