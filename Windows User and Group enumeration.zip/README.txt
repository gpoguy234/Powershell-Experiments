scripts included:
1) Find-AdminCountUser.ps1 - Collects information on all domain users and associated memberships
   (Requires administrator privileges to load the required powershell AD module)
	Run from powershell directly or open in ISE
	Output saved to directory where executed in a json formatted file 
	Output filename is "userstest.json" - edit the script as needed to change file name or adjust attributes collected
2) Get-LocalGroupMembership.ps1 - collects information from specified computers on specified groups. 
   (Requires administrator privileges on specified computers)
	Open in ISE and review syntax included - this script is a function that can be loaded into memory by selecting the contents and pressing F8 (Run selected script) 
	i.e. after loading the function by running the script once, use the powershell cli to enter the following command and see local Administrator members:
	get-LocalGroupMembership -Computername 127.0.0.1 -GroupName "Administrators"
	


